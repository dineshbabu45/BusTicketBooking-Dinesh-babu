﻿using System;
using System.Collections.Generic;


namespace BusTicketBookingApplication
{
    class StartPage
    {
        static void Main()
        {
            
           
            HomePage homePage = new HomePage();
            homePage.ViewHomePage();
           
        }
    }
}
